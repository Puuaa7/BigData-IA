
(function(){
  if(!window.matchMedia||!matchMedia('(hover:hover) and (pointer:fine)').matches)return;
  var circuit=document.createElement('div');circuit.className='hex-hidden-circuit';circuit.setAttribute('aria-hidden','true');document.body.appendChild(circuit);
  var frame=0,x=0,y=0;
  document.addEventListener('pointermove',function(e){if(e.pointerType==='touch')return;if(e.target.closest&&e.target.closest('#hero,.nav')){circuit.classList.remove('revealed');if(frame){cancelAnimationFrame(frame);frame=0}return;}x=e.clientX;y=e.clientY;if(!frame)frame=requestAnimationFrame(function(){circuit.style.setProperty('--hidden-x',x+'px');circuit.style.setProperty('--hidden-y',y+'px');circuit.classList.add('revealed');frame=0})},{passive:true});
  document.documentElement.addEventListener('pointerleave',function(){circuit.classList.remove('revealed')});
  window.addEventListener('blur',function(){circuit.classList.remove('revealed')});
})();
