
(function(){
  'use strict';
  var logo=document.querySelector('.nav .mark');
  if(!logo)return;
  var phase=0,clicks=0,last=0,busy=false,overlay=null,timers=[],ctx=null,osc=null,gain=null,previousFocus=null,savedScroll=0,hiddenNodes=[];
  var reduced=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
  function later(fn,ms){var t=setTimeout(fn,ms);timers.push(t);return t}
  function sound(kind){
    try{
      var AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;
      ctx=new AC();ctx.resume();osc=ctx.createOscillator();gain=ctx.createGain();osc.connect(gain);gain.connect(ctx.destination);
      var now=ctx.currentTime;gain.gain.setValueAtTime(.035,now);osc.type=kind==='alarm'?'sawtooth':'triangle';
      if(kind==='alarm'){for(var i=0;i<7;i++){osc.frequency.setValueAtTime(440,now+i);osc.frequency.linearRampToValueAtTime(880,now+i+.5);osc.frequency.linearRampToValueAtTime(440,now+i+1)}}
      else{osc.frequency.setValueAtTime(100,now);osc.frequency.exponentialRampToValueAtTime(1600,now+5)}
      osc.start();
    }catch(e){}
  }
  function silence(){if(ctx){try{ctx.close()}catch(e){}ctx=null;osc=null;gain=null}}
  function cleanup(){
    if(phase===3)return;
    if(overlay&&(overlay.classList.contains('nora')||overlay.classList.contains('blast'))&&!overlay.classList.contains('return-green')){
      timers.forEach(clearTimeout);timers=[];silence();hiddenNodes.forEach(function(n){n.el.style.visibility=n.visibility});hiddenNodes=[];overlay.classList.remove('blast');overlay.classList.add('return-green');
      later(cleanupNow,850);return;
    }
    cleanupNow();
  }
  function cleanupNow(){
    timers.forEach(clearTimeout);timers=[];silence();document.documentElement.classList.remove('hex-alert');
    if(overlay)overlay.remove();overlay=null;
    document.querySelectorAll('.hex-shard').forEach(function(n){n.remove()});
    hiddenNodes.forEach(function(n){n.el.style.visibility=n.visibility});hiddenNodes=[];
    document.body.style.overflow=oldOverflow;
    busy=false;clicks=0;if(previousFocus&&previousFocus.focus)previousFocus.focus({preventScroll:true});
    window.scrollTo(0,savedScroll);
  }
  var oldOverflow='';
  function open(){
    busy=true;previousFocus=document.activeElement;savedScroll=scrollY;oldOverflow=document.body.style.overflow;document.body.style.overflow='hidden';
    overlay=document.createElement('div');overlay.className='hex-secret';overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('aria-label','Transmisión secreta');
    overlay.innerHTML='<div class="secret-scan"></div><div class="secret-box"></div>';document.body.appendChild(overlay);
  }
  function box(html){overlay.querySelector('.secret-box').innerHTML=html;var b=overlay.querySelector('button');if(b){b.addEventListener('click',cleanup);b.focus()}}
  function alarm(){
    phase=1;open();overlay.classList.add('helix-entry');document.documentElement.classList.add('hex-alert');sound('alarm');
    box('<p>⚠ PROTOCOLO DE CONTENCIÓN HELIX</p><h2>Hemos detectado tu señal</h2><div class="secret-clock" aria-hidden="true">07</div><p role="status">Rastreo activo. Localizando al sujeto HEX.</p><button class="secret-close" type="button">Silenciar alarma</button>');
    var mute=overlay.querySelector('button');mute.removeEventListener('click',cleanup);mute.onclick=function(){silence();this.textContent='Alarma silenciada'};
    for(var i=1;i<=7;i++)(function(n){later(function(){if(n<7){overlay.querySelector('.secret-clock').textContent=('0'+(7-n)).slice(-2)}else{
      silence();document.documentElement.classList.remove('hex-alert');overlay.className='hex-secret nora';
      box('<p>CONEXIÓN HELIX INTERRUMPIDA</p><h2>Nora ha cortado la conexión.</h2><p role="status">«Tranquilo, HEX. He borrado tu rastro. Pero deja de tocar cosas.»</p><button class="secret-close" type="button">Volver a la web</button>');later(cleanup,6500);
    }},n*1000)})(i);
  }
  function explode(){
    phase=2;open();overlay.classList.add('creeper-scene');sound('creeper');
    box('<p>ESA SEÑAL NO ERA DE HELIX…</p><div class="creeper" aria-label="Creeper"><svg viewBox="0 0 16 26" role="img" aria-label="Creeper verde de Minecraft" shape-rendering="crispEdges"><path fill="#4c9b35" d="M1 0h14v14H1zM4 14h8v9H4zM1 22h6v4H1zM9 22h6v4H9z"/><path fill="#76c64d" d="M1 0h5v3H1zM9 1h6v4H9zM2 10h3v4H2zM7 13h5v6H7zM1 22h4v2H1z"/><path fill="#305d24" d="M6 0h3v2H6zM12 8h3v6h-3zM4 16h3v6H4zM10 23h5v3h-5z"/><path fill="#101810" d="M3 4h4v4H3zM9 4h4v4H9zM7 7h2v3H7zM5 9h6v4H9v-2H7v2H5z"/></svg></div><p role="status">Sssssssss…</p><button class="secret-close" type="button">Escapar</button>');
    later(function(){
      silence();
      if(!reduced){
        var elements=document.querySelectorAll('.nav,.hero-copy,.pgw,.reader,.strip-sec,.ana-head,.idea,.block,.foot');
        elements.forEach(function(el){var r=el.getBoundingClientRect();if(r.bottom<0||r.top>innerHeight)return;
          var piece=el.cloneNode(true);piece.removeAttribute('id');piece.querySelectorAll('[id]').forEach(function(n){n.removeAttribute('id')});piece.setAttribute('aria-hidden','true');piece.inert=true;piece.classList.add('hex-shard');
          piece.style.cssText+=';left:'+r.left+'px;top:'+r.top+'px;width:'+r.width+'px;height:'+r.height+'px;margin:0;--dx:'+(r.left+r.width/2-innerWidth/2+(Math.random()-.5)*600)+'px;--dy:'+(r.top+r.height/2-innerHeight/2-250)+'px;--rot:'+((Math.random()-.5)*100)+'deg';document.body.appendChild(piece);
        });
      }
      Array.prototype.forEach.call(document.body.children,function(el){if(el!==overlay&&!el.classList.contains('hex-shard')&&el.tagName!=='SCRIPT'&&el.tagName!=='STYLE'){hiddenNodes.push({el:el,visibility:el.style.visibility});el.style.visibility='hidden'}});
      overlay.className='hex-secret blast';overlay.querySelector('.secret-box').hidden=true;
      later(function(){overlay.querySelector('.secret-box').hidden=false;box('<p>ERROR 404 · WEB VOLADA</p><h2>Nora no puede arreglarlo todo.</h2><p role="status">«Te dije que dejaras de tocar cosas.»</p><button class="secret-close" type="button">Reconstruir la web</button>')},1300);
    },5000);
  }
  function enderman(){
    phase=3;open();overlay.className='hex-secret enderman-scene';
    var mini=document.querySelector('main').cloneNode(true);mini.removeAttribute('id');mini.querySelectorAll('[id]').forEach(function(n){n.removeAttribute('id')});mini.querySelectorAll('.rv').forEach(function(n){n.classList.add('in')});mini.classList.add('stolen-mini');mini.inert=true;
    overlay.innerHTML='<div class="enderman-dust"></div><div class="stolen-cube" aria-hidden="true"><div class="stolen-face front"></div><div class="stolen-face right"></div><div class="stolen-face top"></div></div><div class="enderman-figure" role="img" aria-label="Un enderman se lleva la web"><svg viewBox="0 0 40 120"><path fill="#101013" d="M8 0h24v22H8zM12 23h16v39H12zM12 63h6v57h-6zM22 63h6v57h-6z"/><path class="enderman-arm-left" fill="#101013" d="M2 24h7v62H2z"/><path class="enderman-arm-right" fill="#101013" d="M31 24h7v62h-7z"/><path fill="#211b2b" d="M9 1h22v5H9zM13 24h5v36h-5zM3 25h2v59H3z"/><path fill="#b646e8" d="M10 10h8v4h-8zM22 10h8v4h-8z"/><path fill="#efb4ff" d="M12 11h4v2h-4zM24 11h4v2h-4z"/></svg></div>';
    overlay.querySelectorAll('.stolen-face').forEach(function(face){face.appendChild(mini.cloneNode(true))});
    Array.prototype.forEach.call(document.body.children,function(el){if(el!==overlay&&el.tagName!=='SCRIPT'&&el.tagName!=='STYLE'){el.style.visibility='hidden'}});
    overlay.setAttribute('aria-label','El enderman se ha llevado la web');overlay.tabIndex=-1;overlay.focus();
    later(function(){overlay.style.background='#030205ee';overlay.classList.add('held')},4300);
    later(function(){overlay.classList.add('depart')},5600);
    later(function(){overlay.innerHTML='';overlay.style.background='#030205';overlay.removeAttribute('role');overlay.removeAttribute('aria-modal');overlay.setAttribute('aria-label','La web ha desaparecido')},7300);
  }
  logo.addEventListener('click',function(e){
    e.preventDefault();if(busy)return;var now=Date.now();clicks=now-last<800?clicks+1:1;last=now;
    if(clicks===3){clicks=0;if(phase===0)alarm();else if(phase===1)explode();else enderman()}
  });
  document.addEventListener('keydown',function(e){if(!busy)return;if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();if(phase!==3)cleanup()}else if(e.key==='Tab'){var b=overlay.querySelector('button');e.preventDefault();if(b)b.focus()}else if(['ArrowLeft','ArrowRight','Home','End','PageUp','PageDown',' '].indexOf(e.key)>=0){e.stopImmediatePropagation()}},true);
})();
